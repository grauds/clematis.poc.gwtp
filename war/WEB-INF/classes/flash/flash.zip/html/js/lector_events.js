// JavaScript Document

  function onLessonStart(classId, time){
  
  }
  
  
  function onLessonEnd(classId, time){
  
  }
  
  
  function onUserAdd(classId, userId, time){
  
  }
  
  
  function onUserUnadd(classId, userId, time){
  
  }
  
  
