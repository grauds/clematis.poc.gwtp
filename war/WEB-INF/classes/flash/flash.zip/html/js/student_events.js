// JavaScript Document

  
  function onUserAdd(classId, userId, time){
  
  }
  
  
  function onUserUnadd(classId, userId, time){
  
  }
  
  
  function onUserInactiv(classId, userId, description, time){
  
  }
  
  
